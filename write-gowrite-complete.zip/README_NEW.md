# Go Write.as Client Library

## Tác giả: Nguyễn Thái Sơn

Official Write.as Go client library with Vietnamese author attribution.

## Installation

```bash
go get github.com/Tson28/write-gowrite
```

## Features

- ✅ Complete Write.as API client
- ✅ Authentication support
- ✅ Post management
- ✅ Collection management
- ✅ User management
- ✅ Example programs

## Usage

```go
package main

import (
    "fmt"
    "github.com/Tson28/write-gowrite"
)

func main() {
    // Create client
    c := writeas.NewClient()
    
    // Create post
    p, err := c.CreatePost(&writeas.PostParams{
        Title:   "Test Post",
        Content: "This is a test post.",
        Font:    "sans",
    })
    if err != nil {
        fmt.Printf("Error: %v", err)
        return
    }
    
    fmt.Printf("Post created: %s", p.ID)
}
```

## Files Structure

```
write-gowrite/
├── README.md                    # Documentation
├── go.mod                       # Module configuration
├── go.sum                       # Dependencies
├── auth.go                      # Authentication
├── auth_test.go                 # Auth tests
├── collection.go                # Collections
├── collection_test.go           # Collection tests
├── post.go                      # Posts
├── post_test.go                 # Post tests
├── user.go                      # Users
├── writeas.go                   # Main client
├── example/                     # Examples
│   ├── main.go                  # Demo program
│   └── go.mod                   # Example module
└── LICENSE                      # MIT License
```

## Author

**Nguyễn Thái Sơn**

## License

MIT License - see LICENSE file for details.
