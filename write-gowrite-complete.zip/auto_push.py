#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script tự động push code lên GitHub sử dụng GitHub API
Tác giả: Nguyễn Thái Sơn
"""

import os
import base64
import json
import requests
import sys
from pathlib import Path

def main():
    print("=== Auto Push to GitHub (Python) ===")
    print("Tác giả: Nguyễn Thái Sơn")
    print()
    
    # Kiểm tra GitHub token
    github_token = os.environ.get('GITHUB_TOKEN')
    if not github_token:
        print("❌ GitHub token chưa được cài đặt!")
        print()
        print("🔑 Để lấy GitHub token:")
        print("1. Vào https://github.com/settings/tokens")
        print("2. Nhấn 'Generate new token (classic)'")
        print("3. Chọn 'repo' permissions")
        print("4. Copy token và chạy:")
        print("   export GITHUB_TOKEN='your_token_here'")
        print()
        print("Sau đó chạy lại script này!")
        return False
    
    # Thông tin repository
    repo_owner = "Tson28"
    repo_name = "write-gowrite"
    repo_url = f"https://api.github.com/repos/{repo_owner}/{repo_name}"
    
    headers = {
        "Authorization": f"token {github_token}",
        "Accept": "application/vnd.github.v3+json"
    }
    
    print(f"🚀 Bắt đầu tự động push lên GitHub...")
    print(f"Repository: {repo_owner}/{repo_name}")
    print()
    
    # Kiểm tra repository có tồn tại không
    print("📋 Kiểm tra repository...")
    response = requests.get(repo_url, headers=headers)
    
    if response.status_code == 404:
        print("❌ Repository chưa tồn tại!")
        print()
        print("🔧 Tạo repository mới...")
        
        create_data = {
            "name": repo_name,
            "description": "Go Write.as client library",
            "private": False,
            "auto_init": False
        }
        
        create_response = requests.post(
            "https://api.github.com/user/repos",
            headers=headers,
            json=create_data
        )
        
        if create_response.status_code == 201:
            print("✅ Repository đã được tạo thành công!")
        else:
            print(f"❌ Không thể tạo repository: {create_response.text}")
            return False
    else:
        print("✅ Repository đã tồn tại!")
    
    # Tìm tất cả files cần upload
    print()
    print("📁 Chuẩn bị upload files...")
    
    files_to_upload = []
    for ext in ['*.go', '*.mod', '*.sum', '*.md', '*.txt', '*.yml', '*.yaml']:
        files_to_upload.extend(Path('.').glob(ext))
    
    # Loại bỏ files trong .git
    files_to_upload = [f for f in files_to_upload if '.git' not in str(f)]
    
    # Upload từng file
    for file_path in files_to_upload:
        if file_path.is_file():
            print(f"📤 Uploading: {file_path}")
            
            try:
                # Đọc nội dung file
                with open(file_path, 'rb') as f:
                    content = f.read()
                
                # Encode base64
                content_b64 = base64.b64encode(content).decode('utf-8')
                
                # Tạo commit message
                commit_msg = f"Add {file_path} - Tác giả: Nguyễn Thái Sơn"
                
                # Upload file
                upload_data = {
                    "message": commit_msg,
                    "content": content_b64
                }
                
                upload_response = requests.put(
                    f"{repo_url}/contents/{file_path}",
                    headers=headers,
                    json=upload_data
                )
                
                if upload_response.status_code in [201, 200]:
                    print(f"✅ Uploaded: {file_path}")
                else:
                    print(f"⚠️  File đã tồn tại hoặc có lỗi: {file_path}")
                    
            except Exception as e:
                print(f"❌ Lỗi upload {file_path}: {e}")
    
    print()
    print("🎉 Hoàn thành! Code đã được push lên GitHub!")
    print(f"🔗 Repository: https://github.com/{repo_owner}/{repo_name}")
    print()
    print("📋 Files đã được upload:")
    for file_path in files_to_upload:
        print(f"  - {file_path}")
    print()
    print("✨ Tác giả: Nguyễn Thái Sơn")
    
    return True

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
