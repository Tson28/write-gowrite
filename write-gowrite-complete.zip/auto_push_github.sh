#!/bin/bash

# Script tự động push code lên GitHub sử dụng GitHub API
# Tác giả: Nguyễn Thái Sơn

echo "=== Auto Push to GitHub Script ==="
echo "Tác giả: Nguyễn Thái Sơn"
echo ""

# Kiểm tra GitHub token
if [ -z "$GITHUB_TOKEN" ]; then
    echo "❌ GitHub token chưa được cài đặt!"
    echo ""
    echo "🔑 Để lấy GitHub token:"
    echo "1. Vào https://github.com/settings/tokens"
    echo "2. Nhấn 'Generate new token (classic)'"
    echo "3. Chọn 'repo' permissions"
    echo "4. Copy token và chạy:"
    echo "   export GITHUB_TOKEN='your_token_here'"
    echo ""
    echo "Sau đó chạy lại script này!"
    exit 1
fi

# Thông tin repository
REPO_OWNER="Tson28"
REPO_NAME="write-gowrite"
REPO_URL="https://api.github.com/repos/$REPO_OWNER/$REPO_NAME"

echo "🚀 Bắt đầu tự động push lên GitHub..."
echo "Repository: $REPO_OWNER/$REPO_NAME"
echo ""

# Kiểm tra repository có tồn tại không
echo "📋 Kiểm tra repository..."
RESPONSE=$(curl -s -H "Authorization: token $GITHUB_TOKEN" "$REPO_URL")

if echo "$RESPONSE" | grep -q "Not Found"; then
    echo "❌ Repository chưa tồn tại!"
    echo ""
    echo "🔧 Tạo repository mới..."
    CREATE_RESPONSE=$(curl -s -X POST -H "Authorization: token $GITHUB_TOKEN" \
        -H "Accept: application/vnd.github.v3+json" \
        -d '{
            "name": "'$REPO_NAME'",
            "description": "Go Write.as client library",
            "private": false,
            "auto_init": false
        }' \
        "https://api.github.com/user/repos")
    
    if echo "$CREATE_RESPONSE" | grep -q "name"; then
        echo "✅ Repository đã được tạo thành công!"
    else
        echo "❌ Không thể tạo repository:"
        echo "$CREATE_RESPONSE"
        exit 1
    fi
else
    echo "✅ Repository đã tồn tại!"
fi

# Tạo danh sách files cần upload
echo ""
echo "📁 Chuẩn bị upload files..."

# Tạo file tạm để lưu danh sách files
FILES_LIST=$(find . -type f \( -name "*.go" -o -name "*.mod" -o -name "*.sum" -o -name "*.md" -o -name "*.txt" -o -name "*.yml" -o -name "*.yaml" \) | grep -v ".git" | sort)

# Upload từng file
for file in $FILES_LIST; do
    if [ -f "$file" ]; then
        echo "📤 Uploading: $file"
        
        # Đọc nội dung file
        CONTENT=$(cat "$file" | base64)
        
        # Tạo commit message
        COMMIT_MSG="Add $file - Tác giả: Nguyễn Thái Sơn"
        
        # Upload file sử dụng GitHub API
        UPLOAD_RESPONSE=$(curl -s -X PUT \
            -H "Authorization: token $GITHUB_TOKEN" \
            -H "Accept: application/vnd.github.v3+json" \
            -d '{
                "message": "'$COMMIT_MSG'",
                "content": "'$CONTENT'"
            }' \
            "$REPO_URL/contents/$file")
        
        if echo "$UPLOAD_RESPONSE" | grep -q "content"; then
            echo "✅ Uploaded: $file"
        else
            echo "⚠️  File đã tồn tại hoặc có lỗi: $file"
        fi
    fi
done

echo ""
echo "🎉 Hoàn thành! Code đã được push lên GitHub!"
echo "🔗 Repository: https://github.com/$REPO_OWNER/$REPO_NAME"
echo ""
echo "📋 Files đã được upload:"
echo "$FILES_LIST"
echo ""
echo "✨ Tác giả: Nguyễn Thái Sơn"
