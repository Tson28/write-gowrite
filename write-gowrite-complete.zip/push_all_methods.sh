#!/bin/bash

# Script tổng hợp để push code lên GitHub - thử tất cả các phương pháp
# Tác giả: Nguyễn Thái Sơn

echo "=== Push to GitHub - All Methods ==="
echo "Tác giả: Nguyễn Thái Sơn"
echo ""

# Phương pháp 1: GitHub CLI
echo "🔍 Phương pháp 1: Kiểm tra GitHub CLI..."
if command -v gh &> /dev/null; then
    echo "✅ GitHub CLI đã được cài đặt!"
    echo "🚀 Thử push bằng GitHub CLI..."
    
    if gh auth status &> /dev/null; then
        echo "✅ Đã đăng nhập GitHub!"
        
        # Tạo repository nếu chưa có
        if ! gh repo view Tson28/write-gowrite &> /dev/null; then
            echo "🔧 Tạo repository mới..."
            gh repo create Tson28/write-gowrite --public --description "Go Write.as client library"
        fi
        
        # Clone và push
        if [ ! -d "write-gowrite" ]; then
            gh repo clone Tson28/write-gowrite
        fi
        
        cp -r *.go *.mod *.sum *.md LICENSE example/ write-gowrite/ 2>/dev/null || true
        cd write-gowrite
        git add .
        git commit -m "Update: Add all files - Tác giả: Nguyễn Thái Sơn"
        git push origin main
        
        echo "🎉 Thành công với GitHub CLI!"
        echo "🔗 Repository: https://github.com/Tson28/write-gowrite"
        exit 0
    else
        echo "⚠️  Chưa đăng nhập GitHub CLI"
    fi
else
    echo "❌ GitHub CLI chưa được cài đặt"
fi

echo ""

# Phương pháp 2: GitHub API với token
echo "🔍 Phương pháp 2: Kiểm tra GitHub token..."
if [ ! -z "$GITHUB_TOKEN" ]; then
    echo "✅ GitHub token đã được cài đặt!"
    echo "🚀 Thử push bằng GitHub API..."
    
    # Chạy script Python nếu có
    if command -v python3 &> /dev/null; then
        echo "🐍 Thử với Python script..."
        python3 auto_push.py
        if [ $? -eq 0 ]; then
            echo "🎉 Thành công với Python script!"
            exit 0
        fi
    fi
    
    # Chạy script bash
    echo "🐚 Thử với Bash script..."
    chmod +x auto_push_github.sh
    ./auto_push_github.sh
    if [ $? -eq 0 ]; then
        echo "🎉 Thành công với Bash script!"
        exit 0
    fi
else
    echo "❌ GitHub token chưa được cài đặt"
fi

echo ""

# Phương pháp 3: Tạo hướng dẫn thủ công
echo "🔍 Phương pháp 3: Tạo hướng dẫn thủ công..."
echo "📋 Tạo file hướng dẫn chi tiết..."

cat > PUSH_MANUAL.md << 'EOF'
# Hướng dẫn Push thủ công lên GitHub

## Tác giả: Nguyễn Thái Sơn

### 🎯 Mục tiêu:
Push code lên repository: `git@github.com:Tson28/write-gowrite.git`

### 📁 Files đã được chuẩn bị:
- ✅ Tất cả files `.go` với hashtag `#author: Nguyễn Thái Sơn`
- ✅ `go.mod` và `go.sum`
- ✅ `README.md` và `LICENSE`
- ✅ Example program trong thư mục `example/`
- ✅ File ZIP: `write-gowrite-project.zip`

### 🚀 Các cách push:

#### Cách 1: GitHub Desktop (Dễ nhất)
1. Tải GitHub Desktop: https://desktop.github.com/
2. Clone repository: `git@github.com:Tson28/write-gowrite.git`
3. Copy tất cả files từ thư mục này vào repository
4. Commit và Push

#### Cách 2: GitHub Web Interface
1. Tạo repository: https://github.com/new
   - Name: `write-gowrite`
   - Description: `Go Write.as client library`
2. Upload file ZIP `write-gowrite-project.zip`

#### Cách 3: GitHub CLI
```bash
# Cài đặt
brew install gh

# Đăng nhập
gh auth login

# Tạo repository
gh repo create Tson28/write-gowrite --public

# Clone và push
gh repo clone Tson28/write-gowrite
cp -r * write-gowrite/
cd write-gowrite
git add .
git commit -m "Initial commit: Write.as Go library"
git push
```

#### Cách 4: GitHub API (cần token)
1. Tạo token: https://github.com/settings/tokens
2. Chạy: `export GITHUB_TOKEN='your_token'`
3. Chạy: `python3 auto_push.py` hoặc `./auto_push_github.sh`

### 📞 Hỗ trợ:
- File ZIP: `write-gowrite-project.zip`
- Hướng dẫn chi tiết: `HUONG_DAN_UPLOAD.md`
- Script tự động: `auto_push_github.sh`, `auto_push.py`

**Chúc bạn thành công! 🎉**
EOF

echo "✅ Đã tạo file PUSH_MANUAL.md"
echo ""
echo "📋 Tóm tắt:"
echo "1. GitHub CLI: Chưa cài đặt hoặc chưa đăng nhập"
echo "2. GitHub API: Chưa có token"
echo "3. Thủ công: Đã tạo hướng dẫn chi tiết"
echo ""
echo "🔗 Repository: https://github.com/Tson28/write-gowrite"
echo "📁 File ZIP: write-gowrite-project.zip"
echo "📖 Hướng dẫn: PUSH_MANUAL.md"
echo ""
echo "✨ Tác giả: Nguyễn Thái Sơn"
