#!/bin/bash

# Script đơn giản để push code lên GitHub sử dụng curl
# Tác giả: Nguyễn Thái Sơn

echo "=== Quick Push to GitHub ==="
echo "Tác giả: Nguyễn Thái Sơn"
echo ""

# Kiểm tra GitHub token
if [ -z "$GITHUB_TOKEN" ]; then
    echo "🔑 Để push tự động, bạn cần GitHub token:"
    echo ""
    echo "1. Vào https://github.com/settings/tokens"
    echo "2. Nhấn 'Generate new token (classic)'"
    echo "3. Chọn 'repo' permissions"
    echo "4. Copy token và chạy:"
    echo "   export GITHUB_TOKEN='your_token_here'"
    echo ""
    echo "Sau đó chạy lại script này!"
    echo ""
    echo "Hoặc sử dụng cách thủ công:"
    echo "1. Mở https://github.com/new"
    echo "2. Tạo repository: write-gowrite"
    echo "3. Upload file ZIP: write-gowrite-project.zip"
    exit 1
fi

# Thông tin repository
REPO_OWNER="Tson28"
REPO_NAME="write-gowrite"
REPO_URL="https://api.github.com/repos/$REPO_OWNER/$REPO_NAME"

echo "🚀 Bắt đầu push lên GitHub..."
echo "Repository: $REPO_OWNER/$REPO_NAME"
echo ""

# Kiểm tra repository có tồn tại không
echo "📋 Kiểm tra repository..."
RESPONSE=$(curl -s -H "Authorization: token $GITHUB_TOKEN" "$REPO_URL")

if echo "$RESPONSE" | grep -q "Not Found"; then
    echo "🔧 Tạo repository mới..."
    CREATE_RESPONSE=$(curl -s -X POST -H "Authorization: token $GITHUB_TOKEN" \
        -H "Accept: application/vnd.github.v3+json" \
        -d '{
            "name": "'$REPO_NAME'",
            "description": "Go Write.as client library",
            "private": false,
            "auto_init": false
        }' \
        "https://api.github.com/user/repos")
    
    if echo "$CREATE_RESPONSE" | grep -q "name"; then
        echo "✅ Repository đã được tạo thành công!"
    else
        echo "❌ Không thể tạo repository:"
        echo "$CREATE_RESPONSE"
        exit 1
    fi
else
    echo "✅ Repository đã tồn tại!"
fi

# Upload files
echo ""
echo "📁 Uploading files..."

# Danh sách files cần upload
FILES=(
    "README.md"
    "go.mod"
    "go.sum"
    "auth.go"
    "auth_test.go"
    "collection.go"
    "collection_test.go"
    "post.go"
    "post_test.go"
    "user.go"
    "writeas.go"
    "LICENSE"
)

# Upload từng file
for file in "${FILES[@]}"; do
    if [ -f "$file" ]; then
        echo "📤 Uploading: $file"
        
        # Đọc nội dung file và encode base64
        CONTENT=$(cat "$file" | base64)
        
        # Tạo commit message
        COMMIT_MSG="Add $file - Tác giả: Nguyễn Thái Sơn"
        
        # Upload file
        UPLOAD_RESPONSE=$(curl -s -X PUT \
            -H "Authorization: token $GITHUB_TOKEN" \
            -H "Accept: application/vnd.github.v3+json" \
            -d '{
                "message": "'$COMMIT_MSG'",
                "content": "'$CONTENT'"
            }' \
            "$REPO_URL/contents/$file")
        
        if echo "$UPLOAD_RESPONSE" | grep -q "content"; then
            echo "✅ Uploaded: $file"
        else
            echo "⚠️  File đã tồn tại hoặc có lỗi: $file"
        fi
    else
        echo "⚠️  File không tồn tại: $file"
    fi
done

# Upload example directory
echo ""
echo "📁 Uploading example directory..."
if [ -d "example" ]; then
    for file in example/*; do
        if [ -f "$file" ]; then
            echo "📤 Uploading: $file"
            
            CONTENT=$(cat "$file" | base64)
            COMMIT_MSG="Add $file - Tác giả: Nguyễn Thái Sơn"
            
            UPLOAD_RESPONSE=$(curl -s -X PUT \
                -H "Authorization: token $GITHUB_TOKEN" \
                -H "Accept: application/vnd.github.v3+json" \
                -d '{
                    "message": "'$COMMIT_MSG'",
                    "content": "'$CONTENT'"
                }' \
                "$REPO_URL/contents/$file")
            
            if echo "$UPLOAD_RESPONSE" | grep -q "content"; then
                echo "✅ Uploaded: $file"
            else
                echo "⚠️  File đã tồn tại hoặc có lỗi: $file"
            fi
        fi
    done
fi

echo ""
echo "🎉 Hoàn thành! Code đã được push lên GitHub!"
echo "🔗 Repository: https://github.com/$REPO_OWNER/$REPO_NAME"
echo ""
echo "📋 Files đã được upload:"
for file in "${FILES[@]}"; do
    if [ -f "$file" ]; then
        echo "  ✅ $file"
    fi
done
echo "  ✅ example/ (directory)"
echo ""
echo "✨ Tác giả: Nguyễn Thái Sơn"
