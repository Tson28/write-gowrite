#!/bin/bash

# Script đơn giản để push code lên GitHub
# Tác giả: Nguyễn Thái Sơn

echo "=== Simple Push to GitHub ==="
echo "Tác giả: Nguyễn Thái Sơn"
echo ""

# Kiểm tra GitHub CLI
if command -v gh &> /dev/null; then
    echo "✅ GitHub CLI đã được cài đặt!"
    echo ""
    echo "🚀 Bắt đầu push lên GitHub..."
    
    # Kiểm tra đăng nhập
    if gh auth status &> /dev/null; then
        echo "✅ Đã đăng nhập GitHub!"
        
        # Tạo repository nếu chưa có
        echo "📋 Kiểm tra repository..."
        if ! gh repo view Tson28/write-gowrite &> /dev/null; then
            echo "🔧 Tạo repository mới..."
            gh repo create Tson28/write-gowrite --public --description "Go Write.as client library"
        else
            echo "✅ Repository đã tồn tại!"
        fi
        
        # Clone repository
        echo "📥 Clone repository..."
        if [ ! -d "write-gowrite" ]; then
            gh repo clone Tson28/write-gowrite
        fi
        
        # Copy files
        echo "📁 Copy files..."
        cp -r *.go *.mod *.sum *.md LICENSE example/ write-gowrite/ 2>/dev/null || true
        
        # Push
        cd write-gowrite
        git add .
        git commit -m "Update: Add all files - Tác giả: Nguyễn Thái Sơn"
        git push origin main
        
        echo ""
        echo "🎉 Hoàn thành! Code đã được push lên GitHub!"
        echo "🔗 Repository: https://github.com/Tson28/write-gowrite"
        
    else
        echo "❌ Chưa đăng nhập GitHub!"
        echo "Chạy: gh auth login"
    fi
    
else
    echo "❌ GitHub CLI chưa được cài đặt!"
    echo ""
    echo "🔧 Cài đặt GitHub CLI:"
    echo "1. Tải từ: https://cli.github.com/"
    echo "2. Hoặc chạy: brew install gh"
    echo "3. Sau đó chạy: gh auth login"
    echo ""
    echo "Hoặc sử dụng script auto_push_github.sh với GitHub token!"
fi
