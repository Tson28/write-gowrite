#!/bin/bash

# Script để upload files lên GitHub repository public
# Tác giả: Nguyễn Thái Sơn

echo "=== Upload to Public GitHub Repository ==="
echo "Tác giả: Nguyễn Thái Sơn"
echo ""

# Thông tin repository
REPO_OWNER="Tson28"
REPO_NAME="write-gowrite"
REPO_URL="https://api.github.com/repos/$REPO_OWNER/$REPO_NAME"

echo "🚀 Bắt đầu upload lên GitHub..."
echo "Repository: $REPO_OWNER/$REPO_NAME"
echo ""

# Kiểm tra repository có tồn tại không
echo "📋 Kiểm tra repository..."
RESPONSE=$(curl -s "$REPO_URL")

if echo "$RESPONSE" | grep -q "Not Found"; then
    echo "❌ Repository không tồn tại!"
    echo "Vui lòng tạo repository tại: https://github.com/new"
    echo "Repository name: write-gowrite"
    exit 1
else
    echo "✅ Repository đã tồn tại!"
fi

# Tạo file README với thông tin
echo "📝 Tạo README mới..."
cat > README_NEW.md << 'EOF'
# Go Write.as Client Library

## Tác giả: Nguyễn Thái Sơn

Official Write.as Go client library with Vietnamese author attribution.

## Installation

```bash
go get github.com/Tson28/write-gowrite
```

## Features

- ✅ Complete Write.as API client
- ✅ Authentication support
- ✅ Post management
- ✅ Collection management
- ✅ User management
- ✅ Example programs

## Usage

```go
package main

import (
    "fmt"
    "github.com/Tson28/write-gowrite"
)

func main() {
    // Create client
    c := writeas.NewClient()
    
    // Create post
    p, err := c.CreatePost(&writeas.PostParams{
        Title:   "Test Post",
        Content: "This is a test post.",
        Font:    "sans",
    })
    if err != nil {
        fmt.Printf("Error: %v", err)
        return
    }
    
    fmt.Printf("Post created: %s", p.ID)
}
```

## Files Structure

```
write-gowrite/
├── README.md                    # Documentation
├── go.mod                       # Module configuration
├── go.sum                       # Dependencies
├── auth.go                      # Authentication
├── auth_test.go                 # Auth tests
├── collection.go                # Collections
├── collection_test.go           # Collection tests
├── post.go                      # Posts
├── post_test.go                 # Post tests
├── user.go                      # Users
├── writeas.go                   # Main client
├── example/                     # Examples
│   ├── main.go                  # Demo program
│   └── go.mod                   # Example module
└── LICENSE                      # MIT License
```

## Author

**Nguyễn Thái Sơn**

## License

MIT License - see LICENSE file for details.
EOF

echo "✅ README đã được tạo!"

# Tạo file ZIP mới
echo "📦 Tạo file ZIP mới..."
zip -r write-gowrite-complete.zip . -x "*.git*" "go.tar.gz" "*.zip"

echo ""
echo "🎉 Hoàn thành!"
echo ""
echo "📋 Files đã được chuẩn bị:"
echo "  ✅ README_NEW.md - README mới với thông tin đầy đủ"
echo "  ✅ write-gowrite-complete.zip - File ZIP hoàn chỉnh"
echo "  ✅ Tất cả files .go với hashtag #author: Nguyễn Thái Sơn"
echo ""
echo "🚀 Cách upload:"
echo "1. Mở https://github.com/Tson28/write-gowrite"
echo "2. Nhấn 'Add file' > 'Upload files'"
echo "3. Upload file: write-gowrite-complete.zip"
echo "4. Hoặc upload từng file thủ công"
echo ""
echo "🔗 Repository: https://github.com/Tson28/write-gowrite"
echo ""
echo "✨ Tác giả: Nguyễn Thái Sơn"
