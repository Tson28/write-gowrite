#!/bin/bash

# Script để upload code lên GitHub sử dụng GitHub API
# Tác giả: Nguyễn Thái Sơn

echo "=== Upload to GitHub Script ==="
echo "Tác giả: Nguyễn Thái Sơn"
echo ""

# Kiểm tra xem có file nào cần upload không
if [ ! -f "go.mod" ]; then
    echo "Không tìm thấy file go.mod. Vui lòng chạy script này trong thư mục dự án."
    exit 1
fi

echo "Đang chuẩn bị upload code lên GitHub..."
echo "Repository: git@github.com:Tson28/write-gowrite.git"
echo ""

# Tạo danh sách files cần upload
echo "Danh sách files sẽ được upload:"
find . -type f \( -name "*.go" -o -name "*.mod" -o -name "*.sum" -o -name "*.md" -o -name "*.txt" -o -name "*.yml" -o -name "*.yaml" \) | grep -v ".git" | sort

echo ""
echo "Lưu ý: Bạn cần:"
echo "1. Tạo repository trên GitHub: https://github.com/Tson28/write-gowrite"
echo "2. Có GitHub Personal Access Token"
echo "3. Hoặc sử dụng GitHub Desktop để upload"
echo ""
echo "Nếu bạn có GitHub Personal Access Token, hãy chạy:"
echo "export GITHUB_TOKEN='your_token_here'"
echo ""

# Tạo file README với hướng dẫn
cat > UPLOAD_INSTRUCTIONS.md << 'EOF'
# Hướng dẫn Upload lên GitHub

## Cách 1: Sử dụng GitHub Desktop
1. Tải GitHub Desktop từ: https://desktop.github.com/
2. Clone repository: git@github.com:Tson28/write-gowrite.git
3. Copy tất cả files trong thư mục này vào repository
4. Commit và Push

## Cách 2: Sử dụng GitHub Web Interface
1. Tạo repository mới trên GitHub: https://github.com/Tson28/write-gowrite
2. Upload files thủ công qua web interface
3. Hoặc sử dụng GitHub CLI nếu có

## Cách 3: Sử dụng GitHub API (cần token)
1. Tạo Personal Access Token trên GitHub
2. Chạy script với token:
   ```bash
   export GITHUB_TOKEN='your_token_here'
   ./upload_to_github.sh
   ```

## Files đã được chuẩn bị:
- Tất cả files .go với hashtag #author: Nguyễn Thái Sơn
- go.mod và go.sum
- README.md và LICENSE
- Example program trong thư mục example/
- Cấu hình Git cơ bản

## Tác giả: Nguyễn Thái Sơn
EOF

echo "Đã tạo file UPLOAD_INSTRUCTIONS.md với hướng dẫn chi tiết"
echo ""
echo "Bạn có thể:"
echo "1. Mở GitHub Desktop và clone repository"
echo "2. Copy tất cả files này vào repository"
echo "3. Commit và push"
echo ""
echo "Hoặc sử dụng GitHub Web Interface để upload files thủ công"
echo ""
echo "Script hoàn thành!"
